<?php
require get_template_directory() . '/inc/hooks/home-grids.php';
require get_template_directory() . '/inc/hooks/mailchimp.php';
require get_template_directory() . '/inc/hooks/tgm.php';
require get_template_directory() . '/inc/hooks/breadcrumb.php';
require get_template_directory() . '/inc/hooks/pagination.php';
require get_template_directory() . '/inc/hooks/inner-header.php';
require get_template_directory() . '/inc/hooks/related-posts.php';
require get_template_directory() . '/inc/hooks/carousel-slider.php';
require get_template_directory() . '/inc/hooks/banner-slider.php';